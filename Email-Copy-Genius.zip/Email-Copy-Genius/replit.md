# Email Copy Genius

## Overview

Email Copy Genius is an AI-powered web application that helps coaches, consultants, and small business owners generate persuasive, brand-aligned marketing emails instantly. Users input details about their product, target audience, goals, and preferred tone, and the application leverages Google's Gemini AI to create complete email copy including subject lines, body content, and calls-to-action.

The application features a three-screen workflow: a welcome screen introducing the tool's value proposition, an input form for collecting campaign details, and an output screen displaying the generated email copy with options to regenerate or edit inputs.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 19 with TypeScript, built using Vite as the build tool and development server.

**UI Component System**: Shadcn UI components built on Radix UI primitives, following a Material Design-inspired system with Linear's typography refinement. The design emphasizes clarity and efficiency for productivity-focused users.

**Styling**: Tailwind CSS with a custom design system featuring:
- Inter font family with weights 400-700
- Consistent spacing units (2, 4, 6, 8, 12, 16, 20, 24)
- Custom color system using CSS variables for theming
- Material Design-inspired form components and feedback patterns

**State Management**: React hooks (useState, useCallback) for local component state. React Query (@tanstack/react-query) is configured for server state management, though the current implementation primarily uses client-side state.

**Routing**: Single-page application with screen-based navigation managed through React state (welcome → input → output flow).

**Form Handling**: Controlled components with React Hook Form integration available through the UI component library. Zod schemas for validation.

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript.

**API Structure**: RESTful API with a single primary endpoint:
- `POST /api/generate-email`: Accepts email input parameters and returns AI-generated copy

**Development vs Production**: 
- Development: Vite dev server middleware integrated with Express
- Production: Static file serving from built assets

**Request Handling**: JSON body parsing with raw body preservation for potential webhook integrations. Request/response logging middleware for API endpoints.

**Error Handling**: Try-catch blocks with appropriate HTTP status codes (500 for server errors). Client-friendly error messages returned as JSON.

### External Dependencies

**AI Service**: Google Gemini AI (gemini-2.0-flash-exp model) via @google/genai SDK
- API key authentication via environment variable (GEMINI_API_KEY)
- Used for generating marketing email copy based on structured prompts
- Handles product descriptions, audience targeting, tone matching, and email type variations

**Database**: Drizzle ORM configured for PostgreSQL via @neondatabase/serverless
- Connection via DATABASE_URL environment variable
- Schema defined in shared/schema.ts
- Migrations in ./migrations directory
- Note: Current implementation includes storage interface but uses in-memory storage (MemStorage) for user data

**Session Management**: connect-pg-simple configured for PostgreSQL session storage (infrastructure present but not actively used in current workflow)

**UI Components**: Extensive use of Radix UI primitives (@radix-ui/*) for accessible, unstyled components that are then styled with Tailwind CSS through the Shadcn UI pattern

**Development Tools**:
- Replit-specific plugins for development environment (@replit/vite-plugin-*)
- TypeScript for type safety across the stack
- ESBuild for production bundling

**Font Delivery**: Google Fonts CDN for Inter font family

### Design Patterns

**Shared Schema**: Type definitions and validation schemas shared between client and server via the shared/ directory, ensuring type consistency across the stack.

**Component Composition**: Shadcn UI pattern where components are copied into the project (not installed as dependencies) allowing full customization while maintaining consistency.

**Environment Configuration**: Separation of development and production concerns through NODE_ENV checks and conditional plugin loading.

**Path Aliases**: TypeScript path mapping for clean imports (@/, @shared/, @assets/)