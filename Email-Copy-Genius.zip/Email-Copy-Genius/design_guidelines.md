# Email Copy Genius - Design Guidelines

## Design Approach

**Selected Approach:** Material Design-inspired system with Linear's typography refinement
**Rationale:** This productivity tool requires clarity and efficiency while maintaining professional polish for its marketing-focused audience. Material Design's form components and feedback patterns paired with Linear's refined typography creates a trustworthy, modern experience.

## Core Design Elements

### Typography System
- **Primary Font:** Inter via Google Fonts CDN (weights: 400, 500, 600, 700)
- **Hierarchy:**
  - Hero/Welcome: text-5xl to text-6xl (font-bold)
  - Section Headers: text-3xl to text-4xl (font-semibold)
  - Subsections: text-xl to text-2xl (font-medium)
  - Body: text-base (font-normal)
  - Labels: text-sm (font-medium)
  - Helper text: text-xs (font-normal)
- **Line Heights:** Use relaxed spacing (leading-relaxed for body, leading-tight for headings)
- **Letter Spacing:** -0.02em for large headings, normal for body

### Layout System
- **Spacing Units:** Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24
- **Container Strategy:**
  - Welcome screen: max-w-4xl centered
  - Input form: max-w-3xl centered
  - Output display: max-w-4xl centered
- **Padding:** py-8 to py-16 for sections, px-6 to px-8 for containers
- **Gaps:** gap-6 for form fields, gap-4 for related elements, gap-8 between sections

### Component Library

#### Welcome Screen
- **Hero Section:**
  - Large, bold headline (text-5xl) explaining value proposition
  - Supporting subheadline (text-xl) with key benefits
  - Single prominent CTA button (px-8 py-4, text-lg)
  - Subtle feature highlights below CTA (3-column grid on desktop, stack on mobile)
  - Optional: Testimonial snippet or trust indicator
- **Layout:** Centered, generous vertical spacing (py-16 to py-24)

#### Input Screen
- **Form Container:**
  - White card background with subtle shadow (shadow-lg)
  - Rounded corners (rounded-2xl)
  - Internal padding (p-8 to p-12)
- **Form Fields:**
  - Full-width inputs with consistent height (h-12 for text inputs, h-32 for textareas)
  - Clear labels above each field (mb-2)
  - Rounded inputs (rounded-lg)
  - Border treatment with focus states
  - Helper text below fields when needed (text-xs, mt-1)
- **Dropdowns/Selects:**
  - Custom-styled select elements matching input height
  - Clear visual indication of selected state
  - Dropdown icon on right side
- **Layout:** Single column stack with gap-6 between fields
- **Submit Button:** Full-width or centered, prominent sizing (px-12 py-4)

#### Output Screen
- **Email Display:**
  - White container with generous padding (p-8 to p-12)
  - Rounded corners (rounded-2xl)
  - Monospace or serif font for generated email copy (font-serif or font-mono)
  - Optimal reading width (max-w-prose)
  - Line height optimized for readability (leading-loose)
- **Action Buttons:**
  - Button group with gap-4
  - Primary: "Copy to Clipboard" (solid background)
  - Secondary: "Regenerate" (outline style)
  - Tertiary: "Edit Inputs" (text link or ghost button)
- **Loading State:**
  - Skeleton loader or animated pulse effect
  - Maintains layout structure during generation

#### Navigation Components
- **Back Buttons:** Icon + text, positioned top-left (absolute positioning or flex with justify-between)
- **Progress Indicator:** Breadcrumb or step indicator showing Welcome → Input → Output

#### Buttons (All Contexts)
- **Primary:** Solid fill, px-6 py-3, rounded-lg, font-medium
- **Secondary:** Border outline, same sizing as primary
- **Ghost/Text:** No background, underline on hover
- **Sizing:** Consistent height across button types (h-12 for standard, h-14 for hero CTAs)
- **Icons:** Use Heroicons, 20px or 24px size, positioned left or right of text with gap-2

### Responsive Behavior
- **Breakpoints:**
  - Mobile: Single column, full-width buttons, px-4 padding
  - Tablet (md:): Maintain single column for forms, increase container widths
  - Desktop (lg:): Max-width containers centered, multi-column layouts for feature grids only

### Micro-interactions
- **Form Focus:** Smooth border color transition on input focus
- **Button States:** Scale slightly on hover (scale-105), reduce opacity on disabled
- **Copy Feedback:** Toast notification or temporary checkmark when email is copied
- **Loading:** Subtle pulsing animation for loading states

### Icons
- **Library:** Heroicons (via CDN)
- **Usage:**
  - Form field icons (mail, user, target)
  - Button icons (arrow-right, refresh, clipboard)
  - Feature highlights (check, sparkles, lightning)
- **Size:** 20px (w-5 h-5) for inline, 24px (w-6 h-6) for standalone

### Images
**No hero images required** for this utility-focused app. Visual interest comes from:
- Clean typography
- Well-structured form layouts
- Subtle shadows and depth
- Icon usage for visual hierarchy

If adding visual elements:
- Abstract geometric patterns as subtle background treatments
- Icon illustrations for welcome screen features
- Never sacrifice form clarity for decoration

### Accessibility
- All form inputs have visible labels
- Focus states clearly visible with outline or border change
- Sufficient color contrast for all text
- Touch targets minimum 44x44px
- Keyboard navigation fully supported
- Loading states announced to screen readers