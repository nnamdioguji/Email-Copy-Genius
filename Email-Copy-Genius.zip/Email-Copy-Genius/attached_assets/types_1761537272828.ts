
export type Screen = 'welcome' | 'input' | 'output';

export interface EmailInputs {
  productDescription: string;
  targetAudience: string;
  goal: string;
  tone: string;
  brandName: string;
  emailType: string;
}

export const emailGoals = [
  'Boost sales',
  'Book calls',
  'Nurture leads',
  'Re-engage subscribers',
  'Announce a new product',
];

export const emailTones = [
  'Friendly',
  'Professional',
  'Luxury',
  'Witty',
  'Empathetic',
  'Bold',
];

export const emailTypes = [
    'Promotional',
    'Welcome',
    'Re-engagement',
    'Abandoned cart',
    'Newsletter',
    'Other'
];
