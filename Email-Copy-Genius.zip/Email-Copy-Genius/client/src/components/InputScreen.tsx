import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { emailGoals, emailTones, emailTypes, type EmailInputs } from "@shared/schema";
import { Loader2, Sparkles } from "lucide-react";

interface InputScreenProps {
  onGenerate: (inputs: EmailInputs) => void;
  isLoading: boolean;
  initialData: EmailInputs | null;
}

export default function InputScreen({ onGenerate, isLoading, initialData }: InputScreenProps) {
  const [formData, setFormData] = useState<EmailInputs>(
    initialData || {
      productDescription: "",
      targetAudience: "",
      goal: "",
      tone: "",
      brandName: "",
      emailType: "",
    }
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(formData);
  };

  const updateField = (field: keyof EmailInputs, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="flex items-center justify-center min-h-screen p-6">
      <div className="w-full max-w-3xl">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold mb-2">Create Your Email</h2>
          <p className="text-muted-foreground">Tell us about your email and we'll craft the perfect copy</p>
        </div>

        <Card className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="brandName">Brand Name</Label>
              <Input
                id="brandName"
                data-testid="input-brand-name"
                placeholder="e.g., Acme Co."
                value={formData.brandName}
                onChange={(e) => updateField("brandName", e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="productDescription">Product/Service Description</Label>
              <Textarea
                id="productDescription"
                data-testid="input-product-description"
                placeholder="Describe what you're promoting..."
                value={formData.productDescription}
                onChange={(e) => updateField("productDescription", e.target.value)}
                className="min-h-24"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="targetAudience">Target Audience</Label>
              <Input
                id="targetAudience"
                data-testid="input-target-audience"
                placeholder="e.g., Small business owners, Fitness enthusiasts"
                value={formData.targetAudience}
                onChange={(e) => updateField("targetAudience", e.target.value)}
                required
              />
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="emailType">Email Type</Label>
                <Select
                  value={formData.emailType}
                  onValueChange={(value) => updateField("emailType", value)}
                  required
                >
                  <SelectTrigger id="emailType" data-testid="select-email-type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    {emailTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="goal">Email Goal</Label>
                <Select
                  value={formData.goal}
                  onValueChange={(value) => updateField("goal", value)}
                  required
                >
                  <SelectTrigger id="goal" data-testid="select-goal">
                    <SelectValue placeholder="Select goal" />
                  </SelectTrigger>
                  <SelectContent>
                    {emailGoals.map((goal) => (
                      <SelectItem key={goal} value={goal}>
                        {goal}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="tone">Tone</Label>
              <Select
                value={formData.tone}
                onValueChange={(value) => updateField("tone", value)}
                required
              >
                <SelectTrigger id="tone" data-testid="select-tone">
                  <SelectValue placeholder="Select tone" />
                </SelectTrigger>
                <SelectContent>
                  {emailTones.map((tone) => (
                    <SelectItem key={tone} value={tone}>
                      {tone}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Button
              type="submit"
              className="w-full"
              size="lg"
              disabled={isLoading}
              data-testid="button-generate"
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  Generate Email Copy
                </>
              )}
            </Button>
          </form>
        </Card>
      </div>
    </div>
  );
}
