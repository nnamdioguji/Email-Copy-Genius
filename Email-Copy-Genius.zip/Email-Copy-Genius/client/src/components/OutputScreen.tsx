import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Copy, RefreshCw, ArrowLeft, Loader2, Check } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface OutputScreenProps {
  emailCopy: string;
  onRegenerate: () => void;
  onBack: () => void;
  isLoading: boolean;
}

export default function OutputScreen({ emailCopy, onRegenerate, onBack, isLoading }: OutputScreenProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(emailCopy);
      setCopied(true);
      toast({
        title: "Copied!",
        description: "Email copy has been copied to clipboard",
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Please try again",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen p-6">
      <div className="w-full max-w-4xl">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={onBack}
            data-testid="button-back"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Edit Inputs
          </Button>
        </div>

        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold mb-2">Your Email Copy</h2>
          <p className="text-muted-foreground">Review and customize your AI-generated email</p>
        </div>

        <Card className="p-8 mb-6">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
              <p className="text-muted-foreground">Crafting your perfect email...</p>
            </div>
          ) : (
            <div 
              className="prose prose-slate dark:prose-invert max-w-none"
              data-testid="text-email-output"
            >
              <pre className="whitespace-pre-wrap font-sans text-base leading-relaxed">
                {emailCopy}
              </pre>
            </div>
          )}
        </Card>

        <div className="flex flex-wrap gap-4 justify-center">
          <Button
            onClick={handleCopy}
            size="lg"
            disabled={isLoading}
            data-testid="button-copy"
          >
            {copied ? (
              <>
                <Check className="mr-2 h-5 w-5" />
                Copied!
              </>
            ) : (
              <>
                <Copy className="mr-2 h-5 w-5" />
                Copy to Clipboard
              </>
            )}
          </Button>

          <Button
            onClick={onRegenerate}
            variant="outline"
            size="lg"
            disabled={isLoading}
            data-testid="button-regenerate"
          >
            <RefreshCw className="mr-2 h-5 w-5" />
            Regenerate
          </Button>
        </div>
      </div>
    </div>
  );
}
