import OutputScreen from '../OutputScreen';

export default function OutputScreenExample() {
  const sampleEmail = `Subject: Transform Your Business with Our Premium Solution

Dear Valued Customer,

Are you ready to take your business to the next level? Our cutting-edge solution is designed specifically for entrepreneurs like you who are looking to maximize efficiency and boost productivity.

Here's what makes us different:
- Industry-leading features that save you time
- Dedicated support team available 24/7
- Proven track record with over 10,000 satisfied customers

For a limited time, we're offering an exclusive 30% discount for new customers. Don't miss this opportunity to revolutionize the way you work.

Click here to get started today!

Best regards,
The Team`;

  return (
    <OutputScreen
      emailCopy={sampleEmail}
      onRegenerate={() => console.log('Regenerate clicked')}
      onBack={() => console.log('Back clicked')}
      isLoading={false}
    />
  );
}
