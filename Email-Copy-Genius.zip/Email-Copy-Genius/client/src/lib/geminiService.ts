import type { EmailInputs } from "@shared/schema";

export async function generateEmailCopy(inputs: EmailInputs): Promise<string> {
  try {
    const response = await fetch("/api/generate-email", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(inputs),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || "Failed to generate email copy");
    }

    const data = await response.json();
    return data.emailCopy;
  } catch (error) {
    console.error("Error generating email copy:", error);
    return "Sorry, there was an error generating your email copy. Please check your inputs and try again.";
  }
}
