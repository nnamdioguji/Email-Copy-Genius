import type { Express } from "express";
import { createServer, type Server } from "http";
import { GoogleGenAI } from "@google/genai";
import { emailInputSchema } from "@shared/schema";

function cleanMarkdown(text: string): string {
  // Remove markdown bold formatting (**text** or __text__)
  let cleaned = text.replace(/\*\*(.+?)\*\*/g, '$1');
  cleaned = cleaned.replace(/__(.+?)__/g, '$1');
  
  // Remove markdown italic formatting (*text* or _text_) but not bullet points
  cleaned = cleaned.replace(/([^\n])\*(.+?)\*/g, '$1$2');
  cleaned = cleaned.replace(/([^\n])_(.+?)_/g, '$1$2');
  
  // Remove bullet point asterisks (at start of line)
  cleaned = cleaned.replace(/^\* /gm, '• ');
  cleaned = cleaned.replace(/^- /gm, '• ');
  
  // Remove headers
  cleaned = cleaned.replace(/^#{1,6}\s/gm, '');
  
  // Remove inline code markers
  cleaned = cleaned.replace(/`(.+?)`/g, '$1');
  
  return cleaned;
}

export async function registerRoutes(app: Express): Promise<Server> {
  const ai = new GoogleGenAI({ 
    apiKey: process.env.GEMINI_API_KEY || ""
  });

  app.post("/api/generate-email", async (req, res) => {
    try {
      const validatedData = emailInputSchema.parse(req.body);
      
      const prompt = `You are an expert email copywriter. Create a compelling marketing email based on the following details:

Brand Name: ${validatedData.brandName}
Product/Service: ${validatedData.productDescription}
Target Audience: ${validatedData.targetAudience}
Email Goal: ${validatedData.goal}
Tone: ${validatedData.tone}
Email Type: ${validatedData.emailType}

Write a complete email including:
- Subject line
- Email body with proper structure
- Clear call-to-action

Make it persuasive, engaging, and aligned with the brand voice. Format the output as plain text without any markdown formatting (no asterisks, no bold/italic markers). Use bullet points with • symbol instead of asterisks if listing features.`;

      const result = await ai.models.generateContent({
        model: "gemini-2.0-flash-exp",
        contents: prompt,
      });

      const rawText = result.text || "No content generated";
      const cleanedText = cleanMarkdown(rawText);

      res.json({ emailCopy: cleanedText });
    } catch (error) {
      console.error("Error generating email copy:", error);
      res.status(500).json({ 
        error: "Failed to generate email copy. Please check your inputs and try again." 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
